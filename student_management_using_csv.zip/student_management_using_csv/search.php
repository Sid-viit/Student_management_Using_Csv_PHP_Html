<html>
    <body style="background-image: linear-gradient(to bottom, #33ccff 0%, #ff99cc 100%);">
	  
	  <div class="container"> 
    
	 <br/>
	  <br/>
	<div class="col-md-6" style="margin:20 auto; float:none;">
	<form method="POST" action="">
	<div class="form-group" align="center">
      
      <input type="text" required name="id" class="form-control" placeholder="Enter The Student ID" id="textbox" />
     </div>
	 <br/>
     
     <div class="form-group" align="center">
      <input type="submit" name="submit" class="btn btn-info" value="Search" id='sbox'/>
     </div>
    </form>
	</div>
	</div>
	
	<style>
	#textbox
	{
	font-size:12pt;
	height:32px;
	width:200px;
	}
	#sbox
	{
	font-size:11pt;
	height:35spx;
	width:80px;
	background-color:#48C9B0;
	border-color:black;
	}
	</style>     
     
	      <?php 
		  
		  if(isset($_POST['id']))
		  {
			 
		       $ID=$_POST['id'];
		  echo "<table border='1' align='center' width=200 height=50 >
<tr>
<th>ID</th>
<th>Name</th>
<th>Gender</th>
<th>Date</th>
<th>City</th>
<th>State</th>
<th>Qualification</th>
<th>Email</th>
<th>Stream</th>
</tr>";
    if (($fp = fopen("form.csv", "r")) !== false) {
				   
				   
    while (($row = fgetcsv($fp)) !== false) {
        if($row[0] === $ID) {
			echo '<tr>';
			 foreach ($row as $column) {
        echo "<td>$column</td>";
    }
	echo '</tr>';
	
            
        }
		
    }
	
	echo '</table>';
    fclose($fp);
    	
	
}
        
		  }
		  
			?>
			
            
	</body>	
</html>	