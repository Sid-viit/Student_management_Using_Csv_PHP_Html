
<html>
      
	
    <body>
	      <?php 
		       $ID=$_POST['ID'];
			   $name=$_POST['name'];
			   $dob=$_POST['dob'];
			   $state=$_POST['state'];
			   $city=$_POST['city'];
			   $qualification=$_POST['qualification'];
			   $email=$_POST['email'];
			   $stream=$_POST['stream'];
			   $gender=$_POST['gender'];
			   
			   $data=[$ID,$name,$gender,$dob,$city,$state,$qualification,$email,$stream,' '];
			  
			  $f=fopen('form.csv','a');
			   fputcsv($f,$data);
			   fclose($f);
			?>
         			
			<script>
		alert("Data Saved Successfully");  // display string message
          </script>
		
           <form  action="menu.html">
	 <div class="form-group">
	 
	 <input type="submit" name="ID" id="btn" value="Go Back To Menu" class="form-control"  >
	  </form>
			
	</body>

</html>