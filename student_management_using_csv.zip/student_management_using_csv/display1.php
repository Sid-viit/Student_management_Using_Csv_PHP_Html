<?php

echo "<body style='background-image:linear-gradient(to bottom, #33ccff 0%, #ff99cc 100%)'>";

$handle = fopen("form.csv", "r");
echo "<table border='1' align='center' width=900 height= 500 bgcolor='#D8D8D8'>
<tr>
<th>ID</th>
<th>Name</th>
<th>Gender</th>
<th>Date</th>
<th>City</th>
<th>State</th>
<th>Qualification</th>
<th>Email</th>
<th>Stream</th>
</tr>";

//display header row if true
 
// displaying contents
while ($csvcontents = fgetcsv($handle)) {
    echo '<tr>';
    foreach ($csvcontents as $column) {
        echo "<td>$column</td>";
    }
    echo '</tr>';
}
echo '</table>';
fclose($handle);

?>